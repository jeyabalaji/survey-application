function log(){
					var logout = confirm("Are you sure you want to logout?");

if(logout){
     location.href = "./user/logout.jsp";
					}}